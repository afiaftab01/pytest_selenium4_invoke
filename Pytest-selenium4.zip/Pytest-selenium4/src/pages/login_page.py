from simple_settings import settings

from src.core.base_actions import BaseActions

username = "//*[@id=\"username\"]"
password = "//*[@id=\"password\"]"

class LoginPage(BaseActions):

    def __init__(self, driver, *args, **kwargs):
        super().__init__(driver, *args, **kwargs)

    def get_login_page(self):
        self.driver.get(settings.login_url)

    def validate_login_page(self):
        self.get_ele_obj_by_xpath(username)
        self.get_ele_obj_by_xpath(password)
