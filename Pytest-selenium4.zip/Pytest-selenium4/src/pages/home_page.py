from simple_settings import settings

from src.core.base_actions import BaseActions

create_emp_cta = "//*[@class=\"employee-list-create-employee-btn\"]"
emp_name = "//*[@placeholder=\"Employee Name\"]"
joining_date ="//*[@placeholder=\"Joining Date\"]"
exp_years = "div:nth-child(1) > div > select"
exp_3 = "//option[. = '3 years']"
addr_line1 ="//*[@placeholder=\"Address Line 1\"]"
addr_line2 ="//*[@placeholder=\"Address Line 2\"]"
addr_district ="//*[@placeholder=\"District\"]"
create_cta = "//button[contains(text(),'Create')]"

class HomePage(BaseActions):

    def __init__(self, driver, *args, **kwargs):
        super().__init__(driver, *args, **kwargs)

    def get_employee_url(self):
        self.driver.get(settings.employee_url)

    def create_employee(self):
        self.click_on_ele(create_emp_cta)
        self.send_values(emp_name, "Test")
        self.send_values(joining_date, "03032023")
        self.click_on_css_ele(exp_years)
        self.click_on_ele(exp_3)
        self.send_values(addr_line1,"Address one")
        self.send_values(addr_line2, "Address two")
        self.send_values(addr_district, "EKM")
        self.click_on_ele(create_cta)