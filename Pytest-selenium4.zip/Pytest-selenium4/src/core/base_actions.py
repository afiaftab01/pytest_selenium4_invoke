import time
import unittest
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from src import constants
from src.constants import custom_wait_timeout


class BaseActions(unittest.TestCase):

    def __init__(self, driver, *args, **kwargs):
        super(BaseActions, self).__init__(*args, **kwargs)
        self.driver = driver

    def get_text(self, element):
        return element.text

    def get_ele_obj_by_xpath(self, element):
        self.wait_for_element_visible(self.get_ele_locator(element))
        return self.driver.find_element(By.XPATH, element)

    def get_ele_obj_by_css(self, element):
        self.wait_for_element_visible(self.get_ele_locator_byCss(element))
        return self.driver.find_element(By.CSS_SELECTOR, element)

    def get_ele_locator(self, element, By=By.XPATH):
        return By, element

    def get_ele_locator_byCss(self, element, By=By.CSS_SELECTOR):
        return By, element

    def wait_for_element_presence(self, element):
        wait = WebDriverWait(self.driver, constants.custom_wait_timeout)
        wait.until(EC.presence_of_element_located(element))

    def wait_for_element_visible(self, element):
        wait = WebDriverWait(self.driver, constants.custom_wait_timeout)
        wait.until(EC.visibility_of_element_located(element))

    def click_on_ele(self, element):
        self.get_ele_obj_by_xpath(element).click()

    def click_on_css_ele(self, element):
        self.get_ele_obj_by_css(element).click()

    def send_values(self, element, keys):
        self.get_ele_obj_by_xpath(element).send_keys(keys)

    def set_values(self, element, keys):
        self.get_ele_obj_by_xpath(element).set_value(keys)

    def custom_wait(self):
        time.sleep(custom_wait_timeout)

    def hide_keyboard(self):
        self.driver.hide_keyboard()

    def click_on_ele_down(self, element):
        parentEle = self.get_ele_obj_by_xpath(element)
        parentEle.below(parentEle).click()

