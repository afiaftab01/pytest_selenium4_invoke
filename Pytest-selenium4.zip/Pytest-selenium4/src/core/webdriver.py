from asyncio.log import logger

import selenium

import config as ab_config


class WebDriver:
    __driver = None

    @classmethod
    def get_driver(cls):
        if cls.__driver:
            logger.debug("Reusing existing driver instance")
        else:
            logger.debug("Creating new driver instance")
            cls.__driver = cls.start_instance()
        return cls.__driver

    @classmethod
    def clear_driver(cls):
        cls.__driver = None

    @classmethod
    def fetch_driver(cls):
        return cls.__driver

    def start_instance():
        logger.info("Driver initialization started.!")
        if ab_config.browser.lower() == 'firefox':
            driver = selenium.webdriver.Firefox()
        elif ab_config.browser.lower() == 'chrome':
            driver = selenium.webdriver.Chrome()
        elif ab_config.browser.lower() == 'headless chrome':
            opts = selenium.webdriver.ChromeOptions()
            opts.add_argument('headless')
            driver = selenium.webdriver.Chrome(options=opts)
        else:
            raise Exception(f'Browser "{ab_config.browser}" is not supported')
        return driver
