import os
import unittest
from asyncio.log import logger
import datetime

import allure
from allure_commons.types import AttachmentType

from src.core.webdriver import WebDriver
from src.pages.home_page import HomePage
from src.pages.login_page import LoginPage


class BaseTest(unittest.TestCase):

    def setUp(self):
        self.driver = WebDriver.get_driver()
        self.home_page = HomePage(self.driver)
        self.login_page = LoginPage(self.driver)

    def tearDown(self):
        logger.info(" -----------Test teardown-------------")
        now = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        test_name = self._testMethodName
        for self._testMethodName, error in self._outcome.errors:
            if error:
                logger.debug("Taking screenshot on failure")
                if not os.path.exists('target/screenshots'):
                    os.makedirs('target/screenshots')
                try:
                    self.driver.save_screenshot(f"screenshots/{test_name}_{now}.png")
                    allure.attach(self.driver.get_screenshot_as_png(), name="screenshot_" + now,
                                  attachment_type=AttachmentType.PNG)
                except Exception as e:
                    logger.info(f"Failed to take screenshot:\n{e}")
