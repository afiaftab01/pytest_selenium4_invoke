"""
This module contains shared fixtures.
"""


import os
from asyncio.log import logger
import pytest
import config as ab_config
from src.core.webdriver import WebDriver


def pytest_addoption(parser):
    parser.addoption(
        "--browser", action="store", default="chrome"
    )

    parser.addoption(
        "--envt", action="store", default="dev"
    )


def pytest_configure(config):
    ab_config.pytest_config = config
    ab_config.browser = config.getoption("browser")
    ab_config.environment = config.getoption("envt")
    logger.info("Executing tests on envt : " + ab_config.environment)
    os.environ['SIMPLE_SETTINGS'] = 'config.data_' + ab_config.environment.lower()


@pytest.fixture(scope='session', autouse=True)
def test_teardown():
    yield
    logger.info(" -----------Fixture teardown-------------")
    if WebDriver.fetch_driver() is not None:
        WebDriver.fetch_driver().quit()
        WebDriver.clear_driver()
