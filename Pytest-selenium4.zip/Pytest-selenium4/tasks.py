from invoke import task



@task
def install(c):
    """
    Install dependencies
    """
    c.run('pip3 install -r requirements.txt')


@task
def clean(c):
    """
    Clean up all temp directories
    """
    c.run('rm -rf target/')
    c.run('rm -rf logs/')


@task
def testweb(c):
    """
    Run all the test
    m - Mention the fixture tag to be run
    """
    c.run('pytest -m "sanity" --browser="chrome" --envt="dev" '
          '--alluredir=target/results -s')

@task
def reviewcode(c):
    c.run('python src/utils/code_reviewer.py')

@task
def report(c):
    """
    Opens allure report in a new browser session
    """
    c.run('allure serve target/results')


