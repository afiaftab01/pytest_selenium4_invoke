import allure
import pytest

from src.core.base_test import BaseTest


@pytest.mark.sanity
class EmployeeApplication(BaseTest):

    @allure.story("Test employee login scenarios")
    def test_employee_login(self):
        self.login_page.get_login_page()
        self.login_page.validate_login_page()

    @allure.story("Create employee scenarios")
    def test_employee_creation(self):
        self.home_page.get_employee_url()
        self.home_page.create_employee()
